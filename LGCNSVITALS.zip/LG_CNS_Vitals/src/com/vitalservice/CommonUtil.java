package com.vitalservice;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.services.kms.AWSKMS;
import com.amazonaws.services.kms.AWSKMSClient;
import com.amazonaws.services.kms.model.DecryptRequest;
import com.amazonaws.util.IOUtils;


public class CommonUtil {
	
	private static CommonUtil commonUtil;
	private String dataKey;
	
	public static String getDateFormat(Date date, String format){
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
		return simpleDateFormat.format(date);
	}
	public static CommonUtil getInstance(){
		if(commonUtil == null){
			commonUtil = new CommonUtil();
		}
		return commonUtil;
	}

	public String toEncode(String value){
		String encodedValue = null;
		try {
			encodedValue = Base64.getEncoder().encodeToString(value.getBytes());
		} catch (Exception e){
			
		}
		return encodedValue;
	}
	
	public String toDecode(String value){
		try {
			return new String(Base64.getDecoder().decode(value));
		} catch (Exception e){
			throw new RuntimeException(e.getMessage(), e);
		}
	}
	public static String getDataKey(){
		String dataKey = "2XJ0s0Jxi9ADE+nHjdsvSFje9xmAVh9kyxbFXJQzSMjGoyp9gjE6H5o12fT7Qc9o";
		try {
			AWSCredentials awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
			AWSKMS awsKms = new AWSKMSClient(awsCredentials);
			//AWSKMS awsKms = new AWSKMSClient();
			InputStream inputStream = Class.forName("com.adtservice.CommonUtil").getResourceAsStream("encryptkey.txt");
			byte[] bytes = IOUtils.toByteArray(inputStream);
			
			inputStream.close();
			
//			File file = new File(CommonConstants.SECRETKEYLOCATION);
//		    FileInputStream fileInputStream = new FileInputStream(file);
//		    byte[] bytes = new byte[(int)file.length()];
//		    fileInputStream.read(bytes);
//		    fileInputStream.close();
			DecryptRequest decryptRequest = new DecryptRequest();
		    decryptRequest.setCiphertextBlob(ByteBuffer.wrap(bytes));
		    ByteBuffer plainTextKey = awsKms.decrypt(decryptRequest).getPlaintext();
		    String decryptStr = decrypt(dataKey, makeKey(plainTextKey));
		    return decryptStr;
		} catch (FileNotFoundException fnfe) {
			throw new RuntimeException(fnfe.getMessage());
		} catch (IOException ioe){	
			throw new RuntimeException(ioe.getMessage());
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}
	
	private static String decrypt(String src, Key key){
		try {
			byte[] decodeBase64src = DatatypeConverter.parseBase64Binary(src);
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.DECRYPT_MODE, key);
			
			return new String(cipher.doFinal(decodeBase64src));
			
		} catch (NoSuchAlgorithmException nsae) {
			throw new RuntimeException(nsae.getMessage());
		} catch (NoSuchPaddingException nspe) {
			throw new RuntimeException(nspe.getMessage());
		} catch (InvalidKeyException ike) {
			throw new RuntimeException(ike.getMessage());
		} catch (IllegalBlockSizeException ibse) {
			throw new RuntimeException(ibse.getMessage());
		} catch (BadPaddingException bpe){
			throw new RuntimeException(bpe.getMessage());
		}
	}

	public static Key makeKey(ByteBuffer key) {
		return new SecretKeySpec(getByteArray(key), "AES");
	}

	public static String getString(ByteBuffer b) {

		return new String(getByteArray(b));
	}

	public static byte[] getByteArray(ByteBuffer b) {
		byte[] byteArray = new byte[b.remaining()];
		b.get(byteArray);
		return byteArray;
	}
}
