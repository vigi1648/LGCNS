package com.vitalservice;

public class User {
	public String UserID;
	public String getUserID() {
		return UserID;
	}
	public void setUserID(String userID) {
		UserID = userID;
	}
	public String getPasswordDigest() {
		return PasswordDigest;
	}
	public void setPasswordDigest(String passwordDigest) {
		PasswordDigest = passwordDigest;
	}
	public String PasswordDigest;
	
}
