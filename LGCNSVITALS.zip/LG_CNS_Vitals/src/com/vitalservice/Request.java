package com.vitalservice;

public class Request {
	
	public Orgnigation Organiztion;
	public User User;
	public String Contents;
	public Orgnigation getOrganiztion() {
		return Organiztion;
	}
	public void setOrganiztion(Orgnigation organiztion) {
		Organiztion = organiztion;
	}
	public User getUser() {
		return User;
	}
	public void setUser(User user) {
		User = user;
	}
	public String getContents() {
		return Contents;
	}
	public void setContents(String contents) {
		Contents = contents;
	}
	

}
