package com.vitalservice;

public class Orgnigation {
	public String OrgCode;
	public String getOrgCode() {
		return OrgCode;
	}
	public void setOrgCode(String orgCode) {
		OrgCode = orgCode;
	}
	public String getFacilityCode() {
		return FacilityCode;
	}
	public void setFacilityCode(String facilityCode) {
		FacilityCode = facilityCode;
	}
	public String FacilityCode;

}
