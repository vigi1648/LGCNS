package com.vitalservice;

import com.vitalservice.Orgnigation;
import com.vitalservice.User;

import ca.uhn.hl7v2.DefaultHapiContext;
import ca.uhn.hl7v2.HapiContext;
import ca.uhn.hl7v2.model.Message;
import ca.uhn.hl7v2.model.v24.group.ORM_O01_PATIENT;
import ca.uhn.hl7v2.model.v24.message.ORM_O01;
import ca.uhn.hl7v2.model.v28.message.ADT_A01;
import ca.uhn.hl7v2.model.v28.message.ORU_R01;
import ca.uhn.hl7v2.model.v28.segment.MSH;
import ca.uhn.hl7v2.model.v28.segment.OBX;
import ca.uhn.hl7v2.model.v28.segment.PID;
import ca.uhn.hl7v2.model.v28.segment.SFT;
import ca.uhn.hl7v2.model.v28.segment.STF;
import ca.uhn.hl7v2.parser.Parser;
import ca.uhn.hl7v2.validation.impl.NoValidation;

import com.vitalservice.Reply;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;


import org.tempuri.BasicHttpBinding_ILPAServiceVitalStub;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.util.Base64;

public class VitalService {

	AWSCredentials awsCrdentials = null;
	AmazonDynamoDBClient amazonDynamoDBClient = null;
	
	public Reply sendVitalDataMessage(RequestVital request){
		Reply reply = null;
		HapiContext context = null;
		String msg;
		reply = new Reply();
		
		
		
		try {
			//Check Credentials
			if (CheckCredentials(request.User).equals("false")) // Invalid Credentials
			{
			reply.Code = "4030";
			reply.Message = "Invalid Credentials";
			return reply;
			}
			else if (CheckCredentials(request.User).equals("username or password missing")) // Invalid Credentials
			{
			reply.Code = "4030";
			reply.Message = "Username or Password missing";
			return reply;
			}
			else if (CheckOrg(request.Organiztion).equals("Org missing")) // Invalid Credentials
			{
			reply.Code = "4030";
			reply.Message = "Organization missing";
			return reply;
			}
			else if (CheckOrg(request.Organiztion).equals(""
					+ "")) // Invalid Credentials
			{
			reply.Code = "4030";
			reply.Message = "Wrong Organization Code";
			return reply;
			}
			
			ORM_O01 order = new ORM_O01();
	        ORU_R01 oru = new ORU_R01();
	        
	        ADT_A01 adt = new ADT_A01();
			MSH mshSegment = adt.getMSH();
		//	ca.uhn.hl7v2.model.v24.segment.MSH mshSegment = order.getMSH();
	        mshSegment.getFieldSeparator().setValue("|");
	        mshSegment.getEncodingCharacters().setValue("^~\\&");
	        mshSegment.getSendingApplication().getNamespaceID().setValue("sendingApplication");
	        mshSegment.getSendingFacility().getNamespaceID().setValue("sendingFacility");
	        mshSegment.getReceivingApplication().getNamespaceID().setValue("receivingApplication");
	        mshSegment.getReceivingFacility().getNamespaceID().setValue("receivingFacility");
	        mshSegment.getDateTimeOfMessage().setValue("");
	        mshSegment.getMessageType().getMessageCode().setValue("ORU");
	        mshSegment.getMessageType().getTriggerEvent().setValue("R01");
	        mshSegment.getMessageType().getMessageStructure().setValue("ORU_R01");
	        mshSegment.getMessageControlID().setValue("");
	        mshSegment.getProcessingID().getProcessingID().setValue("");
	        mshSegment.getVersionID().getVersionID().setValue("");
	        
	      //  ORM_O01_PATIENT pid = order.getPATIENT();
	        PID pid = adt.getPID(); 
	        pid.getPid1_SetIDPID().setValue("1");
	        pid.getPatientID().setValue("");
	        pid.getPatientIdentifierList(0).getIDNumber().setValue("");
	        pid.getPatientName(0).getGivenName().setValue("");
	        pid.getPatientName(0).getFamilyName().getFn1_Surname().setValue("");
	        pid.getAdministrativeSex().getIdentifier().setValue("");
	        
	        
	        
	        SFT stf = adt.getSFT();
	        OBX obx = adt.getOBX();
	        
	        
	        obx.getSetIDOBX().setValue("1");
	        obx.getValueType().setValue("ST");
	        obx.getObservationIdentifier().getIdentifier().setValue("");
	        obx.getObservationIdentifier().getText().setValue("");
	        obx.getObservationIdentifier().getCodingSystemOID().setValue("");
	        obx.getObservationIdentifier().getValueSetOID().setValue("");
	      
	        obx.getUnits().getIdentifier().setValue("");
	        obx.getUnits().getText().setValue("");
	        obx.getUnits().getNameOfCodingSystem().setValue("");
	        obx.getObservationResultStatus().setValue("");
	        obx.getDateTimeOfTheObservation().setValue("");
	  //    obx.getEquipmentInstanceIdentifier().s
	   //   obx.getResponsibleObserver()
	        
	        
/*	        patientInfo.setSendingApplication(msh.getSendingApplication().getNamespaceID().getValue());
			patientInfo.setSendingFacility(msh.getSendingFacility().getNamespaceID().getValue());
			patientInfo.setPatientId(pid.getPatientIdentifierList(0).getIDNumber().getValue());
			patientInfo.setGivenName(pid.getPatientName(0).getGivenName().getValue());
			patientInfo.setAdministrativeSex(pid.getAdministrativeSex().getIdentifier().getValue());
			patientInfo.setReceivingApplication(msh.getReceivingApplication().getNamespaceID().getValue());
			patientInfo.setReceivingFacility(msh.getReceivingFacility().getNamespaceID().getValue());
			patientInfo.setFamilyName(pid.getPatientName(0).getFamilyName().getFn1_Surname().getValue());
			patientInfo.setDob(pid.getDateTimeOfBirth().getValue());
			patientInfo.setAdmitDateOrTime(pv1.getAdmitDateTime().getValue());
			patientInfo.setDataOrTimeOfMessage(msh.getDateTimeOfMessage().getValue());
			patientInfo.setDischargeDateOrTime(pv1.getDischargeDateTime().getValue());
			patientInfo.setAssignedPatientLocationBed(pv1.getAssignedPatientLocation().getBed().getNamespaceID().getValue());
			patientInfo.setAssignedPatientLocationBuilding(pv1.getAssignedPatientLocation().getBuilding().getNamespaceID().getValue());
			patientInfo.setAssignedPatientLocationFloor(pv1.getAssignedPatientLocation().getFloor().getNamespaceID().getValue());
//			 patientInfo.setAssignedPatientLocationPointOfCare(assignedPatientLocationPointOfCare);
			patientInfo.setAssignedPatientLocationRoom(pv1.getAssignedPatientLocation().getRoom().getNamespaceID().getValue());
			patientInfo.setMessageControlID(msh.getMessageControlID().getValue());
			patientInfo.setEventOccuredTime(event.getRecordedDateTime().getValue());
			 String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			 patientInfo.setLastModifiedOn(timeStamp);
			 patientInfo.setPriorPatientLocationBed(pv1.getPriorPatientLocation().getBed().getNamespaceID().getValue());
			 patientInfo.setPriorPatientLocationBuilding(pv1.getPriorPatientLocation().getBuilding().getNamespaceID().getValue());
			 patientInfo.setPriorPatientLocationFloor(pv1.getPriorPatientLocation().getFloor().getNamespaceID().getValue());
//			 patientInfo.setPriorPatientLocationPersonLocationType(pv1.);
//			 patientInfo.setPriorPatientLocationPointOfCare(priorPatientLocationPointOfCare);
			 patientInfo.setPriorPatientLocationRoom(pv1.getPriorPatientLocation().getRoom().getNamespaceID().getValue());
			 patientInfo.setAdtEvent(msh.getMessageType().getMessageCode().getValue()+"-"+msh.getMessageType().getTriggerEvent().getValue());*/
			//PatientInfo patientInfo = new PatientInfo();
			
/*//			byte[] valueDecoded= Base64.decode("TVNIfF5+XCZ8TEdDTlN8MTAwMHxOUnxOVVJTRVJPU0lFX0FEVHwyMDE2MDgyMjA5MzgzMC43NDF8fEFEVF5BMTF8MjAwMTAwM3xUfDIuOA0KRVZOfFAxMXwyMDE2MDgwMTEzMDB8fHxwY2MtbmF2YXJrfDIwMTYwODAxMTMwMA0KUElEfDF8fDMzNzc0OTdeXl5eRkl+MDAwMDIwXl5eXkhDfjAwMDAyMF5eXl5QTnx8UGF0aWVudDFeVGVzdHx8MTk2NjExMTJ8Rnx8fHx8fHx8fHwwMDAwMjANClBWMXwxfEl8QV40MDJeQl5eXk5eMjReMXwzIC0gRWxlY3RpdmV8fHx8fHx8fHx8MSAtIFBoeXNpY2lhbiBSZWZlcnJhbHx8fHwyfHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHwyMDE2MDgwMTIzMDB8DQpBTDF8MXx8VG8gQmUgRGV0ZXJtaW5lZA0KSU4xfDF8XlRYIE1lZGljYWlkXl4xMTIwLTIwXk1lZGljYWlkfE1DRHwiInx8fHx8fHx8fHx8TUNEfHxOT05eTm9uZXx8fHxJTg0KWkVWfDIwMDB8MjAxNjA4MDExMzAwfHBjYy1uYXZhcms=");
			byte[] valueDecoded= Base64.decode(request.Contents);
			
			String decodedADT = new String(valueDecoded);
			System.out.println("Decoded value is " + decodedADT);
			
//			String msg = "MSH|^~\\&|Smart|8000||F|20130731132259||ADT^A01|4067|P|2.8|||AL|NE\r"
//					+"EVN|P03|20130731132259||O||20130731132259\r"
//					+"PID|1|R1746|R1746||BATISTE^ANTOINE^||19250228000000|M|||||||||||438261307\r"
//					+"PV1|1|I|U-01^407^A|||||||||||||||||||||||||||||||||||||||||20101005000000";
			 context = new DefaultHapiContext();
			context.setValidationContext(new NoValidation());
//			try {
			 Parser p = context.getGenericParser();
			 Message hapiMsg = p.parse(decodedADT);
			 System.out.println("Decoded value 1 is " + hapiMsg);
			 msg = hapiMsg.getMessage().getName();*/
	        URL url = null;
			 try {
				 
			 // http://lgehrdev.trafficmanager.net/LWebService/LPAService.svc
			 url = new URL("http://localhost:57808/LWebService/LPAService.svc");
			 } catch (MalformedURLException e1) {
			 e1.printStackTrace();
			 }
			 RequestVital request1 = new RequestVital();
			 Orgnigation org = new Orgnigation();
			 org.setOrgCode("NRE");
			 User user = new User();
			 user.setUserID("user id");
			 user.setPasswordDigest("password");
			 request1.setOrganiztion(org);
			 request1.setUser(user);
			 /*
			 String contents = "";
			 Copyright ⓒ 2014 LG CNS Co.,Ltd. All rights reserved 12
			 contents += "MSH|^~\\&|NurseRosieApp|10100|LGCNSEHR|10107|20170731132259||ADT^A01|4067|P|2.3.1|||AL|NE|||||||||\r\n";
			 contents += "PID|1|R1746|R1746||BATISTE^ANTOINE^||19250228000000|M|||||||||||438261307|||||||||||||||||||||\r\n";
			 contents += "STF|1|U2246^^^^^^^|HIPPOCRATES^HAROLD^H^JR^DR^M.D.||||A||||||||||||||||||||||||||||||||||FHNCFODFD84JCMSYGFD\r\n";
			 contents += "OBX|1||BP^BLOOD PRESSURE^||120|mm of Hg||||||||20170731010203|||\r\n";
			 contents += "OBX|2||HR^HEART RATE^||75|beats/minute||||||||'20170731010203|||\r\n";
			 contents += "OBX|3||TP^TEMPERATURE^||75|°F||||||||'20170731010203|||";
			 */
			 String vitalMessageBase64 = "TVNIfF5+XCZ8TnVyc2VSb3NpZUFwcHwxMDEwMHxMR0NOU0VIUnwxMDEwN3wyMDE3MDczMTEzMjI1OXx8QURUXkEwMXw0MDY3fFB8Mi4zLjF8fHxBTHxORXx8fHx8fHx8fA0KRVZOfFAwM3wyMDE3MDczMTEzMjI1OXx8T3x8fA0KUElEfDF8UjE3NDZ8UjE3NDZ8fEJBVElTVEVeQU5UT0lORV58fDE5MjUwMjI4MDAwMDAwfE18fHx8fHx8fHx8fDQzODI2MTMwN3x8fHx8fHx8fHx8fHx8fHx8fHx8fA0KU1RGfDF8VTIyNDZeXl5eXl5efEhJUFBPQ1JBVEVTXkhBUk9MRF5IXkpSXkRSXk0uRC58fHx8QXx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHxGSE5DRk9ERkQ4NEpDTVNZR0ZEDQpPQlh8MXx8QlBeQkxPT0QgUFJFU1NVUkVefHwxMjB8bW0gb2YgSGd8fHx8fHx8fDIwMTcwNzMxMDEwMjAzfHx8DQpPQlh8Mnx8SFJeSEVBUlQgUkFURV58fDc1fGJlYXRzL21pbnV0ZXx8fHx8fHx8JzIwMTcwNzMxMDEwMjAzfHx8DQpPQlh8M3x8VFBeVEVNUEVSQVRVUkVefHw3NXzCsEZ8fHx8fHx8fCcyMDE3MDczMTAxMDIwM3x8fA==";
			 request1.setContents(vitalMessageBase64); //Base64 String
			 try {
			 BasicHttpBinding_ILPAServiceVitalStub stub = new BasicHttpBinding_ILPAServiceVitalStub(url, null);
			 Reply reply1 = stub.requestVitalService(request1);
			 System.out.print(reply1.getCode());
			 } catch (RemoteException e) {
			 // TODO Auto-generated catch block
			 System.out.print(e.toString());
			 }
			  
		return reply;
		}catch(Exception e){
			System.out.println(e.toString());
		}
	}
	
	private String CheckCredentials(User user)
	{
		
		if(user.UserID == null || user.PasswordDigest == null)
		{
			System.out.println(user.UserID);
			return "username or password missing";
		}
		else if(user.UserID.equals("zsluser") && user.PasswordDigest.equals("test123"))
		{
		//Check CheckCredentials
		return "true"; // check Credentials return fasle
		}
		else
		{
		
			return "false";
		}
	}
	private String CheckOrg(Orgnigation orgnigation)
	{
		System.out.println("org code" + orgnigation.OrgCode);
		if(orgnigation.OrgCode == null)
		{
			System.out.println("org code" + orgnigation.OrgCode);
			return "Org missing";
		}
		else if(orgnigation.OrgCode.equals("ZSLFACILITY"))
		{
		//Check CheckCredentials
		return "true"; // check Credentials return fasle
		}
		else
		{
		
			return "false";
		}
	}
}
