package com.amazonaws.lambda.demo;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;

public class AWSAuthenticationUtil {

	public static AWSCredentials getAWSCredentials(){
        AWSCredentials awsCredentials = null;
        try {
               awsCredentials = new BasicAWSCredentials("AKIAIOU3LFO4T7GJ3OFQ", "3OoZKAHbJkkp72H9gDjk2dzT0G4bRMrXkzajz3F0");
               
        } catch (Exception e) {
              
        }

 return awsCredentials;
 }
}
