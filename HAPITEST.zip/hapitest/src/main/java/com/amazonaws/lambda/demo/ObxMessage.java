package com.amazonaws.lambda.demo;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import ca.uhn.hl7v2.model.v28.datatype.TX;
import ca.uhn.hl7v2.model.v28.group.ORU_R01_OBSERVATION;
import ca.uhn.hl7v2.model.v28.group.ORU_R01_ORDER_OBSERVATION;
import ca.uhn.hl7v2.model.v28.message.ORU_R01;
import ca.uhn.hl7v2.model.v28.segment.MSH;
import ca.uhn.hl7v2.model.v28.segment.OBX;
import ca.uhn.hl7v2.model.v28.segment.PID;
import ca.uhn.hl7v2.util.Terser;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;

public class ObxMessage {
	
	public static void main(String [] args){
		try {
			ORU_R01 message = new ORU_R01();
			
			MSH msh = message.getMSH();
			msh.getSendingApplication().getNamespaceID().setValue("NurseRosieApp");
			msh.getReceivingApplication().getNamespaceID().setValue("LGCNSEHR");
			msh.getSendingFacility().getNamespaceID().setValue("10100");
			msh.getReceivingFacility().getNamespaceID().setValue("10107");
			msh.getDateTimeOfMessage().setValue("199902280700");
			msh.getMessageControlID().setValue("897565");
			message.initQuickstart("ORU", "R01", "P");
			
			
			PID pid = message.getPATIENT_RESULT(0).getPATIENT().getPID();
			pid.getSetIDPID().setValue("1");
			pid.getPatientIdentifierList(0).getIDNumber().setValue("R1746");
			pid.getPatientName(0).getFamilyName().getFn1_Surname().setValue("BATISTE");
			pid.getPatientName(0).getGivenName().setValue("ANTOINE");
			pid.getDateTimeOfBirth().setValue("19250228000000");
			pid.getAdministrativeSex().getIdentifier().setValue("M");
			
			Terser terser = new Terser(message);

			terser.set("/.STF-1", "1");
			terser.set("/.STF-2-1", "U2246");
			terser.set("/.STF-3-1", "HIPPOCRATES");
			terser.set("/.STF-3-2", "HAROLD");
			terser.set("/.STF-3-4", "JR");
			terser.set("/.STF-3-5", "DR");
			terser.set("/.STF-3-6", "M.D.");
			
//			STF stf = new STF(message.getParent(), message.getModelClassFactory());
//			stf.getPrimaryKeyValueSTF().getIdentifier().setValue("1");
//			stf.getStaffIdentifierList(0).getIDNumber().setValue("U2246");
//			stf.getStaffName(0).getFamilyName().getFn1_Surname().setValue("HIPPOCRATES");
//			stf.getStaffName(0).getGivenName().setValue("HAROLD");
//			stf.getStaffName(0).getSuffixEgJRorIII().setValue("JR");
//			stf.getStaffName(0).getPrefixEgDR().setValue("DR");
//			stf.getStaffName(0).getDegreeEgMD().setValue("M.D.");
//			stf.getActiveInactiveFlag().setValue("A");
//			message.addNonstandardSegment("STF", 1);
//			message.addNonstandardSegment(stf.toString());
			
			 ORU_R01_ORDER_OBSERVATION orderObservation = message.getPATIENT_RESULT().getORDER_OBSERVATION();
			 //OBR obr = orderObservation.getOBR();
			 //obr.getSetIDOBR().setValue("1");
			 //obr.getUniversalServiceIdentifier().getIdentifier().setValue("12345");
			 
			 
			ORU_R01_OBSERVATION observation = orderObservation.getOBSERVATION(0);
			
			OBX obx = observation.getOBX();
			
			//OBX|1|ST|8310-5^TEMPERATURE^LN||98.1|[degF]^degree 
			obx.getSetIDOBX().setValue("1");
			obx.getObservationIdentifier().getIdentifier().setValue("BP");
			obx.getObservationIdentifier().getText().setValue("BLOOD PRESSURE");
			
			obx.getValueType().setValue("TX");
			TX tx = new TX(message);
			tx.setValue("120");
			obx.getObservationValue(0).setData(tx);
				
//			obx.getUnits().getAlternateText().setValue("millimeter mercury");
			obx.getUnits().getIdentifier().setValue("mm of Hg");
			//obx.getUnits().getAlternateCodingSystemOID().setValue("UCUM");
			
//			obx.getObservationResultStatus().setValue("F");
			
			obx.getDateTimeOfTheObservation().setValue("20170731010203");
//			obx.getObservationMethod(0).getAlternateText().setValue("SIT");
//			obx.getObservationMethod(1).getAlternateText().setValue("Small");
//			
//			obx.getObservationSite(0).getAlternateText().setValue("LA");
//			
//			obx.getEquipmentInstanceIdentifier(0).getEi1_EntityIdentifier().setValue("1");
			
			String hl7Message = message.encode();
			String hl7MessageUpdated = hl7Message.replace("OBR|\r", "");
			String hl7MessageFormated = hl7MessageUpdated.substring(0, hl7MessageUpdated.length()-2);
			byte[] hl7Encoded = Base64.getEncoder().encode(hl7MessageUpdated.getBytes());
			System.out.println(hl7MessageFormated);
			String s = new String(hl7Encoded, StandardCharsets.UTF_8);
			System.out.println(s);
			AWSCredentials awsCredentials = AWSAuthenticationUtil.getAWSCredentials();
			AmazonDynamoDBClient amazonDynamoDBClient = new AmazonDynamoDBClient(awsCredentials);
			
			DynamoDBMapper dynamoDBMapper =  new DynamoDBMapper(amazonDynamoDBClient);
			com.amazonaws.lambda.demo.Message message1 = new com.amazonaws.lambda.demo.Message();
			message1.setMessage(hl7MessageFormated);
			dynamoDBMapper.save(message1);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}
}
