package com.amazonaws.lambda.demo;

import java.util.Arrays;

import ca.uhn.hl7v2.HL7Exception;
import ca.uhn.hl7v2.model.v28.message.ORU_R01;
import ca.uhn.hl7v2.parser.DefaultModelClassFactory;
import ca.uhn.hl7v2.parser.ModelClassFactory;

@SuppressWarnings("serial")
public class STF extends ORU_R01 {

   /**
    * Constructor
    */
   public STF() throws HL7Exception {
      this(new DefaultModelClassFactory());
   }

   /**
    * Constructor
    * 
    * We always have to have a constructor with this one argument
    */
   public STF(ModelClassFactory factory) throws HL7Exception {
      super(factory);

      // Now, let's add the ZPI segment at the right spot
      String[] segmentNames = getNames();
      int indexOfPid = Arrays.asList(segmentNames).indexOf("PID");

      // Put the ZPI segment right after the PID segment
      int index = indexOfPid + 1;

      Class<STF> type = STF.class;
      boolean required = true;
      boolean repeating = false;

      this.add(type, required, repeating, index);
   }

   /**
    * Add an accessor for the ZPI segment
    */
   public STF getSTF() throws HL7Exception {
      return getTyped("STF", STF.class);
   }

}

